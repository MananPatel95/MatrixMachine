package com.manan.MatrixMachine;

import android.app.Activity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;



public class MainActivity extends Activity {

    EditText xrows_ele, xcolumns_ele, row1col1_ele, row1col2_ele, row1col3_ele,row1col4_ele, row1col5_ele, row1col6_ele;
    String rowmaxStr, columnmaxStr;
    EditText row2col1_ele, row2col2_ele, row2col3_ele, row2col4_ele, row2col5_ele, row2col6_ele;
    EditText row3col1_ele, row3col2_ele, row3col3_ele, row3col4_ele, row3col5_ele, row3col6_ele;
    EditText row4col1_ele, row4col2_ele, row4col3_ele, row4col4_ele, row4col5_ele, row4col6_ele;
    EditText row5col1_ele, row5col2_ele, row5col3_ele, row5col4_ele, row5col5_ele, row5col6_ele;
    EditText row6col1_ele, row6col2_ele, row6col3_ele, row6col4_ele, row6col5_ele, row6col6_ele;
    TextView output_ele, numberOfRowsLabel, numberOfColumnsLabel, insLabel;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        xrows_ele = (EditText)findViewById(R.id.xrows);
        xcolumns_ele = (EditText)findViewById(R.id.xcolumns);

        output_ele = (TextView)findViewById(R.id.outputLabel);
        numberOfRowsLabel = (TextView)findViewById(R.id.XRowsLabel);
        numberOfColumnsLabel = (TextView)findViewById(R.id.xColumnsLabel);

        insLabel = (TextView)findViewById(R.id.InstructionLabel);

        row1col1_ele = (EditText)findViewById(R.id.row1col1);
        row1col2_ele = (EditText)findViewById(R.id.row1col2);
        row1col3_ele = (EditText)findViewById(R.id.row1col3);
        row1col4_ele = (EditText)findViewById(R.id.row1col4);
        row1col5_ele = (EditText)findViewById(R.id.row1col5);
        row1col6_ele = (EditText)findViewById(R.id.row1col6);

        row2col1_ele = (EditText)findViewById(R.id.row2col1);
        row2col2_ele = (EditText)findViewById(R.id.row2col2);
        row2col3_ele = (EditText)findViewById(R.id.row2col3);
        row2col4_ele = (EditText)findViewById(R.id.row2col4);
        row2col5_ele = (EditText)findViewById(R.id.row2col5);
        row2col6_ele = (EditText)findViewById(R.id.row2col6);

        row3col1_ele = (EditText)findViewById(R.id.row3col1);
        row3col2_ele = (EditText)findViewById(R.id.row3col2);
        row3col3_ele = (EditText)findViewById(R.id.row3col3);
        row3col4_ele = (EditText)findViewById(R.id.row3col4);
        row3col5_ele = (EditText)findViewById(R.id.row3col5);
        row3col6_ele = (EditText)findViewById(R.id.row3col6);

        row4col1_ele = (EditText)findViewById(R.id.row4col1);
        row4col2_ele = (EditText)findViewById(R.id.row4col2);
        row4col3_ele = (EditText)findViewById(R.id.row4col3);
        row4col4_ele = (EditText)findViewById(R.id.row4col4);
        row4col5_ele = (EditText)findViewById(R.id.row4col5);
        row4col6_ele = (EditText)findViewById(R.id.row4col6);

        row5col1_ele = (EditText)findViewById(R.id.row5col1);
        row5col2_ele = (EditText)findViewById(R.id.row5col2);
        row5col3_ele = (EditText)findViewById(R.id.row5col3);
        row5col4_ele = (EditText)findViewById(R.id.row5col4);
        row5col5_ele = (EditText)findViewById(R.id.row5col5);
        row5col6_ele = (EditText)findViewById(R.id.row5col6);

        row6col1_ele = (EditText)findViewById(R.id.row6col1);
        row6col2_ele = (EditText)findViewById(R.id.row6col2);
        row6col3_ele = (EditText)findViewById(R.id.row6col3);
        row6col4_ele = (EditText)findViewById(R.id.row6col4);
        row6col5_ele = (EditText)findViewById(R.id.row6col5);
        row6col6_ele = (EditText)findViewById(R.id.row6col6);




    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    
    public final String nullspace(double[][] orig, int rowmax, int columnmax)
    {
        java.util.ArrayList<Integer> list = new java.util.ArrayList<Integer>();

        for (int i = 1; i <= rowmax; i++)
        {
            boolean found = false;
            for (int j = 1; j <= columnmax; j++)
            {
                if ((!found) && (orig[i][j] == 1))
                {
                    list.add(j);
                    found = true;
                }
            }

            if (!found)
            {
                rowmax = rowmax - 1;
            }
        }

        double[][] tempmat = new double[rowmax + 1][columnmax - list.size() + 1];

        for (int i = 1; i <= rowmax; i++)
        {
            int skipper = 0;
            for (int j = 1; j <= columnmax; j++)
            {
                if (!list.contains(j))
                {
                    tempmat[i][j - skipper] = orig[i][j] * -1;
                }
                else
                {
                    skipper++;
                }

            }
        }

        double[][] imat = new double[columnmax - list.size() + 1][columnmax - list.size() + 1];

        double[][] nullmat = new double[columnmax + 1][columnmax - list.size() + 1];

        makeInverse(imat, columnmax - list.size(), columnmax - list.size(), orig);

        int iTime = 0;

        for (int i = 1; i <= columnmax; i++)
        {
            if (list.contains(i))
            {
                for (int j = 1; j <= columnmax - list.size(); j++)
                {
                    nullmat[i][j] = tempmat[i - iTime][j];
                }
            }
            else
            {
                iTime++;
                for (int j = 1; j <= columnmax - list.size(); j++)
                {
                    nullmat[i][j] = imat[iTime][j];
                }
            }
        }

        double[][] newnullmat = new double[columnmax - list.size() + 1][columnmax + 1];

        makeTranspose(newnullmat, columnmax, columnmax - list.size(), nullmat);

        return stringrowspace(rationalize(newnullmat, columnmax - list.size(), columnmax), columnmax - list.size(), columnmax);
    }

    public final String[][] rationalize(double[][] inverse, int rowmax, int columnmax)
    {
        String[][] newinverse = new String[rowmax + 1][columnmax + 1];

        for (int i = 1; i <= rowmax; i++)
        {
            for (int j = 1; j <= columnmax; j++)
            {
                if (Math.round((inverse[i][j] % 1) * Math.pow(10, 4)) / Math.pow(10, 4) != 0)
                {
                    double numerator = inverse[i][j];
                    int denominator = 0;

                    boolean done = false;
                    while (!done)
                    {
                        denominator++;
                        if ((Math.round((denominator * numerator) * Math.pow(10, 4)) / Math.pow(10, 4) % 1) == 0)
                        {
                            numerator = numerator * denominator;
                            done = true;
                        }

                    }
                    if ((Math.round(numerator * Math.pow(10, 4)) / Math.pow(10, 4)) != denominator)
                    {
                        newinverse[i][j] = String.valueOf(Math.round(numerator * Math.pow(10, 2)) / Math.pow(10, 2)) + "/" + String.valueOf(denominator) + "    ";
                    }
                    else
                    {
                        newinverse[i][j] = "1" + "   ";
                    }
                }
                else
                {
                    newinverse[i][j] = String.valueOf(Math.round(inverse[i][j] * Math.pow(10, 4)) / Math.pow(10, 4)) + "    ";
                }
            }
        }

        return newinverse;
    }

    public final void roundmatrix(double[][] orig, int rowmax, int columnmax)
    {
        for (int i = 1; i <= rowmax; i++)
        {
            for (int j = 1; j <= columnmax; j++)
            {
                orig[i][j] = Math.round(orig[i][j] * Math.pow(10, 2)) / Math.pow(10, 2);
            }
        }
    }

    public final void totalsimplify(double[][] orig, int rowmax, int columnmax, double[][] inverse, boolean inv)
    {
        int x = columnmax;
        int y = rowmax;
        int times = 0;

        while ((x >= 1) && (y >= 1))
        {
            boolean erase1st = false;
            int allzeroes = 0;

            for (int i = 1; i <= y; i++)
            {
                if (orig[i + times][1 + times] != 0)
                {
                    erase1st = true;
                }
            }

            if (!erase1st)
            {
                x = x - 1;
                allzeroes++;
            }

            double[][] newsmall = new double[y + 1][x + 1];

            for (int i = 1; i <= y; i++)
            {
                for (int j = 1; j <= x; j++)
                {
                    newsmall[i][j] = orig[i + times][j + times + allzeroes];
                }
            }

            simplify(newsmall, y, x, inverse, rowmax, times, inv);

            for (int i = 1; i <= y; i++)
            {
                for (int j = 1; j <= x; j++)
                {
                    orig[i + times][j + times + allzeroes] = newsmall[i][j];
                }
            }

            times = times + 1;
            y = y - 1;
            x = x - 1;
        }
    }

    public final double[][] makeTranspose(double[][] transpose, int rowmax, int columnmax, double[][] orig)
    {
        for (int i = 1; i <= rowmax; i++)
        {
            for (int j = 1; j <= columnmax; j++)
            {
                transpose[j][i] = orig[i][j];

            }
        }
        return transpose;

    }


    public final void makeInverse(double[][] inverse, int rowmax, int columnmax, double[][] orig)
    {
        for (int i = 1; i <= rowmax; i++)
        {
            for (int j = 1; j <= rowmax; j++)
            {
                if (i == j)
                {
                    inverse[i][j] = 1;
                }
                else
                {
                    inverse[i][j] = 0;
                }
            }
        }
    }

    public final boolean printrow(double[][] orig, int columnmax, int i)
    {
        boolean printit = false;
        for (int j = 1; j <= columnmax; j++)
        {
            if (orig[i][j] != 0)
            {
                printit = true;
            }
        }
        return printit;
    }

    public final boolean stringprintrow(String[][] orig, int columnmax, int i)
    {
        boolean printit = false;
        for (int j = 1; j <= columnmax; j++)
        {
            if (!orig[i][j].equals("0"))
            {
                printit = true;
            }
        }
        return printit;
    }

    public final double determinant(double[][] mat, int rowmax, int columnmax)
    {
        double det = 0;

        if (rowmax == columnmax)
        {
            if (rowmax == 1)
            {
                det = mat[1][1];
                return det;
            }
            else
            {
                for (int i = 1; i <= rowmax; i++)
                {
                    double[][] smallmat = new double[rowmax][columnmax];

                    for (int k = 1; k <= rowmax; k++)
                    {
                        for (int j = 2; j <= columnmax; j++)
                        {
                            if (k < i)
                            {
                                smallmat[k][j - 1] = mat[k][j];
                            }
                            else if (k > i)
                            {
                                smallmat[k - 1][j - 1] = mat[k][j];
                            }
                        }
                    }
                    det = det + mat[i][1] * Math.pow(-1, i - 1) * determinant(smallmat, rowmax - 1, columnmax - 1);
                }
            }
        }
        return det;
    }

    public final String rowspace(double[][] orig, int rowmax, int columnmax)
    {
        String rowspaceOutput = "\n{[";
        if ((rowmax >= 1) && (columnmax >= 1))
        {
            boolean printnorows = false;
            for (int i = 1; i <= rowmax; i++)
            {
                for (int j = 1; j <= columnmax; j++)
                {
                    if ((printrow(orig, columnmax, i)) && (!printnorows))
                    {
                        if (((i == rowmax) && (j == columnmax)) || ((i != rowmax) && (!printrow(orig, columnmax, i + 1)) && (j == columnmax)))
                        {
                            rowspaceOutput += String.valueOf(orig[i][j]) + "]}\n";
                        }

                        else if (j == columnmax)
                        {
                            rowspaceOutput += String.valueOf(orig[i][j]) + "]\n [";
                        }
                        else
                        {
                            rowspaceOutput += String.valueOf(orig[i][j]) + ", ";
                        }
                    }
                    else
                    {
                        printnorows = true;
                    }
                }
            }
        }
        else
        {
            rowspaceOutput = "{0}\n";
        }

        return rowspaceOutput;
    }

    public final String stringrowspace(String[][] orig, int rowmax, int columnmax)
    {
        String rowspaceOutput = "\n{[";
        if ((rowmax >= 1) && (columnmax >= 1))
        {
            for (int i = 1; i <= rowmax; i++)
            {
                for (int j = 1; j <= columnmax; j++)
                {
                    if (stringprintrow(orig, columnmax, i))
                    {
                        if (((i == rowmax) && (j == columnmax)) || ((i != rowmax) && (!stringprintrow(orig, columnmax, i + 1)) && (j == columnmax)))
                        {
                            rowspaceOutput += String.valueOf(orig[i][j]) + "]}\n";
                        }

                        else if (j == columnmax)
                        {
                            rowspaceOutput += String.valueOf(orig[i][j]) + "]\n [";
                        }
                        else
                        {
                            rowspaceOutput += String.valueOf(orig[i][j]) + ", ";
                        }
                    }
                }
            }
        }
        else
        {
            rowspaceOutput = "{0}";
        }

        boolean allzeroes = true;

        for (int i = 1; i <= rowmax; i++)
        {
            for (int j = 1; j <= columnmax; j++)
            {
                if (!orig[i][j].equals("0"))
                {
                    allzeroes = false;
                }
            }
        }

        if (allzeroes)
        {
            rowspaceOutput = "{0}";
        }


        return rowspaceOutput;
    }

    public final void print(double[][] orig) {// int rowmax, int columnmax) {
        int m = orig.length;
        int n = orig[0].length;

        String entry = "";

        for (int y = 1; y < m; y++)
        //for (int i = 1; i <= rowmax; i++)
        {
            for (int x = 1; x < n; x++)
            //for (int j = 1; j <= columnmax; j++)
            {
                output_ele.append(entry + orig[y][x] + "   ");
            }

            output_ele.append(entry + "\n");

        }


    }

                /*String entry = String.valueOf(orig[i][j]);

                String tab = "";

                for (int k = 1; k <= 7 - entry.length(); k++)
                {
                    tab = tab + " ";
                }
                output_ele.append(entry + tab);

            }

            output_ele.append("\n");
        }
    }*/

  /*  public static String matrixToString(int[][] a)
    {
        int m = a.length;
        int n = a[0].length;

        String tmp = "";

        for(int y = 0; y<m; y++)
        {
            for(int x = 0; x<n; x++)
            {
                tmp = tmp + a[y][x] + " ";
            }

            tmp = tmp + "\n";
        }

        return tmp;
    }*/





    public final void stringprint(String[][] orig, int rowmax, int columnmax)
    {

        for (int i = 1; i <= rowmax; i++) {
            for (int j = 1; j <= columnmax; j++) {
                String entry = String.valueOf(orig[i][j]);

                String tab = "";

                for (int k = 1; k <= 7 - entry.length(); k++) {
                    tab = tab + " ";
                }

                output_ele.append(entry + tab);
            }

            output_ele.append("\n");
        }
    }

    public final boolean check(double[][] orig, int rowmax, int columnmax)
    {
        int goodRows = 0;
        for (int i = 1; i <= rowmax; i++)
        {
            int zerolen = 0;
            int zeromin = i - 1;

            for (int j = 1; ((j <= columnmax) && (orig[i][j] == 0)); j++)
            {
                zerolen++;
            }

            if ((zerolen == columnmax) || (zerolen >= zeromin))
            {
                goodRows++;
            }
        }

        if (goodRows == rowmax)
        {
            return true;
        }
        else
        {
            return false;
        }
    }


    public final double[][] simplify(double[][] orig, int rowmax, int columnmax, double[][] inverse, int origrowmax, int times, boolean inv)
    {
        boolean done = false;
        if (rowmax == 1)
        {
            boolean execute = true;
            for (int i = 1; i <= columnmax - 1; i++)
            {
                if (orig[1][i] != 0)
                {
                    execute = false;
                }
            }

            if ((execute) && (orig[1][columnmax] != 0))
            {
                if ((inv) && (rowmax == columnmax) && (determinant(orig, rowmax, columnmax) != 0))
                {
                    double placeholder = orig[1][columnmax];
                    for (int i = 1; i <= origrowmax; i++)
                    {
                        inverse[1 + times][i] = inverse[1 + times][i] / placeholder;
                    }
                }

                for (int i = 1; i <= columnmax; i++)
                {
                    orig[1][columnmax] = 1;
                    done = true;
                }
            }
        }

        if ((!done) && (rowmax >= 1) && (columnmax >= 1))
        {
            if (orig[1][1] != 0)
            {
                double divisor = orig[1][1];
                for (int i = 1; i <= columnmax; i++)
                {
                    orig[1][i] = orig[1][i] / divisor;
                }
                if ((inv) && (rowmax == columnmax) && (determinant(orig, rowmax, columnmax) != 0))
                {
                    for (int i = 1; i <= origrowmax; i++)
                    {
                        inverse[1 + times][i] = inverse[1 + times][i] / divisor;
                    }
                }

                for (int i = 2; i <= rowmax; i++)
                {
                    if (orig[i][1] != 0)
                    {
                        double placeholder = orig[i][1];
                        for (int j = 1; j <= columnmax; j++)
                        {
                            orig[i][j] = orig[i][j] - (placeholder * orig[1][j]);
                        }

                        if ((inv) && (rowmax == columnmax) && (determinant(orig, rowmax, columnmax) != 0))
                        {
                            for (int j = 1; j <= origrowmax; j++)
                            {
                                inverse[i + times][j] = inverse[i + times][j] - inverse[1 + times][j] * placeholder;
                            }
                        }
                    }
                }
            }
            else
            {
                boolean found = false;
                for (int i = 1; i <= rowmax; i++)
                {
                    if ((!found) && (orig[i][1] != 0))
                    {
                        for (int j = 1; j <= columnmax; j++)
                        {
                            double placeholder = orig[i][j];
                            orig[i][j] = orig[1][j];
                            orig[1][j] = placeholder;
                        }

                        if ((inv) && (rowmax == columnmax) && (determinant(orig, rowmax, columnmax) != 0))
                        {
                            for (int j = 1; j <= origrowmax; j++)
                            {
                                double placeholder = inverse[i + times][j];
                                inverse[i + times][j] = inverse[1 + times][j];
                                inverse[1 + times][j] = placeholder;
                            }
                        }

                        found = true;
                    }
                }

                if (found)
                {
                    double divisor = orig[1][1];
                    for (int i = 1; i <= columnmax; i++)
                    {
                        orig[1][i] = orig[1][i] / divisor;
                    }

                    if ((inv) && (rowmax == columnmax) && (determinant(orig, rowmax, columnmax) != 0))
                    {
                        for (int i = 1; i <= origrowmax; i++)
                        {
                            inverse[1 + times][i] = inverse[1 + times][i] / divisor;
                        }
                    }
                }
            }
        }

        return orig;
    }

    public final double[][] finalizerref(double[][] orig, int rowmax, int columnmax, double[][] inverse, boolean inv)
    {
        int leadingOneAdder = 1;
        for (int j = 1; ((j <= rowmax) && (j <= columnmax)); j++)
        {
            boolean done = false;
            while (!done)
            {
                boolean go = false;
                for (int i = 1; i <= columnmax; i++)
                {
                    if (orig[j][i] != 0)
                    {
                        go = true;
                    }
                }
                if (!go)
                {
                    done = true;
                }


                if ((go) && (orig[j][leadingOneAdder] != 0))
                {
                    for (int i = 1; i < j; i++)
                    {
                        //label3.Text += "\n adding " + Convert.ToString(orig[i, j]) + " times row " + Convert.ToString(j) + " to row " + Convert.ToString(i);
                        double placeholder = orig[i][leadingOneAdder];
                        for (int k = 1; k <= columnmax; k++)
                        {
                            orig[i][k] = orig[i][k] - (orig[j][k] * placeholder);

                            if ((inv) && (rowmax == columnmax) && (determinant(orig, rowmax, columnmax) != 0))
                            {
                                inverse[i][k] = inverse[i][k] - (inverse[j][k] * placeholder);
                            }
                        }
                    }
                    done = true;
                }
                leadingOneAdder++;
            }
        }

        return orig;
    }

    public static String fmt(double d)
    {
        if(d == (long) d)
            return String.format("%d",(long)d);
        else
            return String.format("%s",d);
    }


    public void buttonOnClick(View v) {
        Button button=(Button) v;
        ((Button)v).setText("Compute");


        rowmaxStr = String.valueOf(xrows_ele.getText());

        columnmaxStr = String.valueOf(xcolumns_ele.getText());

        int rowmax = Integer.parseInt(rowmaxStr);
        int columnmax = Integer.parseInt(columnmaxStr);

        String row1col1String, row1col2String, row1col3String;


        if (TextUtils.isEmpty(rowmaxStr) || TextUtils.isEmpty(columnmaxStr))

        {
            xrows_ele.setError("Please enter number of rows.");
            xcolumns_ele.setError("Please enter number of columns.");
        }


        else

        {

            insLabel.setVisibility(View.GONE);


            double[][] orig = new double[Integer.parseInt(String.valueOf(rowmax + 1))][Integer.parseInt(String.valueOf(columnmax + 1))];

            if ((rowmax >= 1) && (columnmax >= 1))
                orig[1][1] = Double.parseDouble(String.valueOf(row1col1_ele.getText()));
            if ((rowmax >= 1) && (columnmax >= 2)) {
                orig[1][2] = Double.parseDouble(String.valueOf(row1col2_ele.getText()));
            }
            if ((rowmax >= 1) && (columnmax >= 3)) {
                orig[1][3] = Double.parseDouble(String.valueOf(row1col3_ele.getText()));
            }
            if ((rowmax >= 1) && (columnmax >= 4)) {
                orig[1][4] = Double.parseDouble(String.valueOf(row1col4_ele.getText()));
            }
            if ((rowmax >= 1) && (columnmax >= 5)) {
                orig[1][5] = Double.parseDouble(String.valueOf(row1col5_ele.getText()));
            }
            if ((rowmax >= 1) && (columnmax >= 6)) {
                orig[1][6] = Double.parseDouble(String.valueOf(row1col6_ele.getText()));
            }


            if ((rowmax >= 2) && (columnmax >= 1)) {
                orig[2][1] = Double.parseDouble(String.valueOf(row2col1_ele.getText()));
            }
            if ((rowmax >= 2) && (columnmax >= 2)) {
                orig[2][2] = Double.parseDouble(String.valueOf(row2col2_ele.getText()));
            }
            if ((rowmax >= 2) && (columnmax >= 3)) {
                orig[2][3] = Double.parseDouble(String.valueOf(row2col3_ele.getText()));
            }
            if ((rowmax >= 2) && (columnmax >= 4)) {
                orig[2][4] = Double.parseDouble(String.valueOf(row2col4_ele.getText()));
            }
            if ((rowmax >= 2) && (columnmax >= 5)) {
                orig[2][5] = Double.parseDouble(String.valueOf(row2col5_ele.getText()));
            }
            if ((rowmax >= 2) && (columnmax >= 6)) {
                orig[2][6] = Double.parseDouble(String.valueOf(row2col6_ele.getText()));
            }


            if ((rowmax >= 3) && (columnmax >= 1)) {
                orig[3][1] = Double.parseDouble(String.valueOf(row3col1_ele.getText()));
            }
            if ((rowmax >= 3) && (columnmax >= 2)) {
                orig[3][2] = Double.parseDouble(String.valueOf(row3col2_ele.getText()));
            }
            if ((rowmax >= 3) && (columnmax >= 3)) {
                orig[3][3] = Double.parseDouble(String.valueOf(row3col3_ele.getText()));
            }
            if ((rowmax >= 3) && (columnmax >= 4)) {
                orig[3][4] = Double.parseDouble(String.valueOf(row3col4_ele.getText()));
            }
            if ((rowmax >= 3) && (columnmax >= 5)) {
                orig[3][5] = Double.parseDouble(String.valueOf(row3col5_ele.getText()));
            }
            if ((rowmax >= 3) && (columnmax >= 6)) {
                orig[3][6] = Double.parseDouble(String.valueOf(row3col6_ele.getText()));
            }


            if ((rowmax >= 4) && (columnmax >= 1)) {
                orig[4][1] = Double.parseDouble(String.valueOf(row4col1_ele.getText()));
            }
            if ((rowmax >= 4) && (columnmax >= 2)) {
                orig[4][2] = Double.parseDouble(String.valueOf(row4col2_ele.getText()));
            }
            if ((rowmax >= 4) && (columnmax >= 3)) {
                orig[4][3] = Double.parseDouble(String.valueOf(row4col3_ele.getText()));
            }
            if ((rowmax >= 4) && (columnmax >= 4)) {
                orig[4][4] = Double.parseDouble(String.valueOf(row4col4_ele.getText()));
            }
            if ((rowmax >= 4) && (columnmax >= 5)) {
                orig[4][5] = Double.parseDouble(String.valueOf(row4col5_ele.getText()));
            }
            if ((rowmax >= 4) && (columnmax >= 6)) {
                orig[4][6] = Double.parseDouble(String.valueOf(row4col6_ele.getText()));
            }


            if ((rowmax >= 5) && (columnmax >= 1)) {
                orig[5][1] = Double.parseDouble(String.valueOf(row5col1_ele.getText()));
            }
            if ((rowmax >= 5) && (columnmax >= 2)) {
                orig[5][2] = Double.parseDouble(String.valueOf(row5col2_ele.getText()));
            }
            if ((rowmax >= 5) && (columnmax >= 3)) {
                orig[5][3] = Double.parseDouble(String.valueOf(row5col3_ele.getText()));
            }
            if ((rowmax >= 5) && (columnmax >= 4)) {
                orig[5][4] = Double.parseDouble(String.valueOf(row5col4_ele.getText()));
            }
            if ((rowmax >= 5) && (columnmax >= 5)) {
                orig[5][5] = Double.parseDouble(String.valueOf(row5col5_ele.getText()));
            }
            if ((rowmax >= 5) && (columnmax >= 6)) {
                orig[5][6] = Double.parseDouble(String.valueOf(row5col6_ele.getText()));
            }


            if ((rowmax >= 6) && (columnmax >= 1)) {
                orig[6][1] = Double.parseDouble(String.valueOf(row6col1_ele.getText()));
            }
            if ((rowmax >= 6) && (columnmax >= 2)) {
                orig[6][2] = Double.parseDouble(String.valueOf(row6col2_ele.getText()));
            }
            if ((rowmax >= 6) && (columnmax >= 3)) {
                orig[6][3] = Double.parseDouble(String.valueOf(row6col3_ele.getText()));
            }
            if ((rowmax >= 6) && (columnmax >= 4)) {
                orig[6][4] = Double.parseDouble(String.valueOf(row6col4_ele.getText()));
            }
            if ((rowmax >= 6) && (columnmax >= 5)) {
                orig[6][5] = Double.parseDouble(String.valueOf(row6col5_ele.getText()));
            }
            if ((rowmax >= 6) && (columnmax >= 6)) {
                orig[6][6] = Double.parseDouble(String.valueOf(row6col6_ele.getText()));
            }

            double[][] inverse = new double[rowmax + 1][columnmax + 1];

            double[][] transpose = new double[columnmax + 1][rowmax + 1];

            if ((rowmax == columnmax) && (determinant(orig, rowmax, columnmax) != 0)) {
                makeInverse(inverse, rowmax, columnmax, orig);
            }

            output_ele.setText("");
            output_ele.append("\n");
            output_ele.append("Transpose Matrix:  \n");
            print(makeTranspose(transpose, rowmax, columnmax, orig));
            //print(transposeMatrix(orig),rowmax,columnmax);
            output_ele.append("\n");


            if (rowmax == columnmax) {
                output_ele.append("Determinant = " + String.valueOf(determinant(orig, rowmax, columnmax)) + "\n\n");
            }

            totalsimplify(transpose, columnmax, rowmax, inverse, false);
            totalsimplify(orig, rowmax, columnmax, inverse, true);

            finalizerref(transpose, columnmax, rowmax, inverse, false);
            finalizerref(orig, rowmax, columnmax, inverse, true);

            // output_ele.append("Determinant: " + determinant(orig, rowmax, columnmax) + "\n");

            //roundmatrix(orig, rowmax, columnmax);
            //roundmatrix(transpose, columnmax, rowmax);

            output_ele.append("Row Reduced Echelon From: \n");
            stringprint(rationalize(orig, rowmax, columnmax), rowmax, columnmax);
            output_ele.append("\n");


            if ((rowmax == columnmax) && (determinant(orig, rowmax, columnmax) != 0)) {
                output_ele.append("Inverse Matrix\n");
                stringprint(rationalize(inverse, rowmax, columnmax), rowmax, columnmax);
            } else {
                output_ele.append("Matrix is not invertible.\n");
            }

            output_ele.append("\nBasis of Rowspace:");
            output_ele.append(stringrowspace(rationalize(orig, rowmax, columnmax), rowmax, columnmax));

            output_ele.append("\nBasis of Columnspace:");
            output_ele.append(stringrowspace(rationalize(transpose, columnmax, rowmax), columnmax, rowmax));

            output_ele.append("\nBasis of Nullspace:");
            output_ele.append(nullspace(orig, rowmax, columnmax));
            output_ele.append("\n");

            output_ele.append("\nBasis of Left Nullspace:");
            output_ele.append(nullspace(transpose, columnmax, rowmax));

            row1col1_ele.setVisibility(View.GONE);
            row1col2_ele.setVisibility(View.GONE);
            row1col3_ele.setVisibility(View.GONE);
            row1col4_ele.setVisibility(View.GONE);
            row1col5_ele.setVisibility(View.GONE);
            row1col6_ele.setVisibility(View.GONE);

            row2col1_ele.setVisibility(View.GONE);
            row2col2_ele.setVisibility(View.GONE);
            row2col3_ele.setVisibility(View.GONE);
            row2col4_ele.setVisibility(View.GONE);
            row2col5_ele.setVisibility(View.GONE);
            row2col6_ele.setVisibility(View.GONE);

            row3col1_ele.setVisibility(View.GONE);
            row3col2_ele.setVisibility(View.GONE);
            row3col3_ele.setVisibility(View.GONE);
            row3col4_ele.setVisibility(View.GONE);
            row3col5_ele.setVisibility(View.GONE);
            row3col6_ele.setVisibility(View.GONE);

            row4col1_ele.setVisibility(View.GONE);
            row4col2_ele.setVisibility(View.GONE);
            row4col3_ele.setVisibility(View.GONE);
            row4col4_ele.setVisibility(View.GONE);
            row4col5_ele.setVisibility(View.GONE);
            row4col6_ele.setVisibility(View.GONE);

            row5col1_ele.setVisibility(View.GONE);
            row5col2_ele.setVisibility(View.GONE);
            row5col3_ele.setVisibility(View.GONE);
            row5col4_ele.setVisibility(View.GONE);
            row5col5_ele.setVisibility(View.GONE);
            row5col6_ele.setVisibility(View.GONE);

            row6col1_ele.setVisibility(View.GONE);
            row6col2_ele.setVisibility(View.GONE);
            row6col3_ele.setVisibility(View.GONE);
            row6col4_ele.setVisibility(View.GONE);
            row6col5_ele.setVisibility(View.GONE);
            row6col6_ele.setVisibility(View.GONE);

            xrows_ele.setVisibility(View.GONE);
            xcolumns_ele.setVisibility(View.GONE);

            numberOfRowsLabel.setVisibility(View.GONE);
            numberOfColumnsLabel.setVisibility(View.GONE);

        }



    }



    public void buttonOnClickd(View v) {
        Button clearButton = (Button) v;
        ((Button) v).setText("Clear");

        insLabel.setVisibility(View.VISIBLE);

        row1col1_ele.setVisibility(View.VISIBLE);
        row1col2_ele.setVisibility(View.VISIBLE);
        row1col3_ele.setVisibility(View.VISIBLE);
        row1col4_ele.setVisibility(View.VISIBLE);
        row1col5_ele.setVisibility(View.VISIBLE);
        row1col6_ele.setVisibility(View.VISIBLE);

        row2col1_ele.setVisibility(View.VISIBLE);
        row2col2_ele.setVisibility(View.VISIBLE);
        row2col3_ele.setVisibility(View.VISIBLE);
        row2col4_ele.setVisibility(View.VISIBLE);
        row2col5_ele.setVisibility(View.VISIBLE);
        row2col6_ele.setVisibility(View.VISIBLE);

        row3col1_ele.setVisibility(View.VISIBLE);
        row3col2_ele.setVisibility(View.VISIBLE);
        row3col3_ele.setVisibility(View.VISIBLE);
        row3col4_ele.setVisibility(View.VISIBLE);
        row3col5_ele.setVisibility(View.VISIBLE);
        row3col6_ele.setVisibility(View.VISIBLE);

        row4col1_ele.setVisibility(View.VISIBLE);
        row4col2_ele.setVisibility(View.VISIBLE);
        row4col3_ele.setVisibility(View.VISIBLE);
        row4col4_ele.setVisibility(View.VISIBLE);
        row4col5_ele.setVisibility(View.VISIBLE);
        row4col6_ele.setVisibility(View.VISIBLE);

        row5col1_ele.setVisibility(View.VISIBLE);
        row5col2_ele.setVisibility(View.VISIBLE);
        row5col3_ele.setVisibility(View.VISIBLE);
        row5col4_ele.setVisibility(View.VISIBLE);
        row5col5_ele.setVisibility(View.VISIBLE);
        row5col6_ele.setVisibility(View.VISIBLE);

        row6col1_ele.setVisibility(View.VISIBLE);
        row6col2_ele.setVisibility(View.VISIBLE);
        row6col3_ele.setVisibility(View.VISIBLE);
        row6col4_ele.setVisibility(View.VISIBLE);
        row6col5_ele.setVisibility(View.VISIBLE);
        row6col6_ele.setVisibility(View.VISIBLE);

        xrows_ele.setVisibility(View.VISIBLE);
        xcolumns_ele.setVisibility(View.VISIBLE);

        numberOfRowsLabel.setVisibility(View.VISIBLE);
        numberOfColumnsLabel.setVisibility(View.VISIBLE);

        output_ele.setText("");

        row1col1_ele.setText("");
        row1col2_ele.setText("");
        row1col3_ele.setText("");
        row1col4_ele.setText("");
        row1col5_ele.setText("");
        row1col6_ele.setText("");

        row2col1_ele.setText("");
        row2col2_ele.setText("");
        row2col3_ele.setText("");
        row2col4_ele.setText("");
        row2col5_ele.setText("");
        row2col6_ele.setText("");

        row3col1_ele.setText("");
        row3col2_ele.setText("");
        row3col3_ele.setText("");
        row3col4_ele.setText("");
        row3col5_ele.setText("");
        row3col6_ele.setText("");

        row4col1_ele.setText("");
        row4col2_ele.setText("");
        row4col3_ele.setText("");
        row4col4_ele.setText("");
        row4col5_ele.setText("");
        row4col6_ele.setText("");

        row5col1_ele.setText("");
        row5col2_ele.setText("");
        row5col3_ele.setText("");
        row5col4_ele.setText("");
        row5col5_ele.setText("");
        row5col6_ele.setText("");

        row6col1_ele.setText("");
        row6col2_ele.setText("");
        row6col3_ele.setText("");
        row6col4_ele.setText("");
        row6col5_ele.setText("");
        row6col6_ele.setText("");

        xrows_ele.setText("");
        xcolumns_ele.setText("");



    }




   /* private void rows_TextChanged(actionEvent)
    {
        Editable strrowmax = xrows_ele.getText();
        Editable strcolumnmax = xcolumns_ele.getText();

        int rowmax = 0;
        int columnmax = 0;

        if (((strrowmax.equals("1")) || (strrowmax.equals("2")) || (strrowmax.equals("3")) || (strrowmax.equals("4")) || (strrowmax.equals("5")) || (strrowmax.equals("6")) || (strrowmax.equals("7")) || (strrowmax.equals("8"))) && ((strcolumnmax.equals("1")) || (strcolumnmax.equals("2")) || (strcolumnmax.equals("3")) || (strcolumnmax.equals("4")) || (strcolumnmax.equals("5")) || (strcolumnmax.equals("6")) || (strcolumnmax.equals("7")) || (strcolumnmax.equals("8"))))
        {
            rowmax = Short.parseShort(String.valueOf(strrowmax));
            columnmax = Short.parseShort(String.valueOf(strcolumnmax));

            if ((rowmax >= 1) && (columnmax >= 1))
            {
                row1col1_ele.setVisibility(View.VISIBLE);
            }
            else
            {
                row1column1.Hide();
            }
            if ((rowmax >= 1) && (columnmax >= 2))
            {
                row1col2_ele.setVisibility(View.VISIBLE);
            }
            else
            {
                row1column2.Hide();
            }
            if ((rowmax >= 1) && (columnmax >= 3))
            {
                row1col3_ele.setVisibility(View.VISIBLE);
            }
            else
            {
                row1column3.Hide();
            }
            if ((rowmax >= 1) && (columnmax >= 4))
            {
                row1column4.Show();
            }
            else
            {
                row1column4.Hide();
            }
            if ((rowmax >= 1) && (columnmax >= 5))
            {
                row1column5.Show();
            }
            else
            {
                row1column5.Hide();
            }
            if ((rowmax >= 1) && (columnmax >= 6))
            {
                row1column6.Show();
            }
            else
            {
                row1column6.Hide();
            }
*/


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;        }

        return super.onOptionsItemSelected(item);
    }
}
